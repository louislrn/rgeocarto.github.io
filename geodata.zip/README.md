# geodata

Ce dépôt contient les données utilisées et décrites dans [Géomatique et cartpgraphie avec R](https://rgeocarto.github.io/).

Pour utiliser les données il suffit de télécharger le dépôt puis de le décompresser.  
Vous pourrez ensuite jouer l'ensemble des exemples proposés.    

