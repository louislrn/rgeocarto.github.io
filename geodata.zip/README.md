# geodata

Ce dépôt contient les données utilisées et décrites dans les documents suivants : 

- [Géomatique avec R](https://rcarto.github.io/geomatique_avec_r/)
- [Cartographie avec R](https://rcarto.github.io/cartographie_avec_r/)

Pour utiliser les données il suffit de télécharger le dépôt puis de le décompresser.
Vous pourrez ensuite jouer l'ensemble des exemples proposés.    

